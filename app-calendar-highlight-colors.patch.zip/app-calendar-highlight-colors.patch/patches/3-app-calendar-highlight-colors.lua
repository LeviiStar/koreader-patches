local original_require = require

_G.require = function(modname)
    local loaded = original_require(modname)

    -- =========================================================
    -- 1. ADD PINK TO THE SELECTION POPUP MENU
    -- =========================================================
    if modname == "apps/reader/modules/readerhighlight" and type(loaded) == "table" then
        local _ = original_require("gettext")
        local has_pink = false
        for _, color in ipairs(loaded.highlight_colors) do
            if color[2] == "pink" then has_pink = true break end
        end
        if not has_pink then
            -- Insert Pink into the menu right before Gray
            table.insert(loaded.highlight_colors, 9, {_("Pink"), "pink"})
        end
        
        -- Rename Olive to Lime and Green to Forest in the popup
        for _, color in ipairs(loaded.highlight_colors) do
            if color[2] == "olive" then color[1] = _("Lime") end
            if color[2] == "green" then color[1] = _("Forest") end
        end
    end

    -- =========================================================
    -- 2. CALENDAR HIGHLIGHT SYNC (Fixed Pink Dropout)
    -- =========================================================
    if modname == "statistics.koplugin/calendarview" and type(loaded) == "table" and not loaded._highlight_patched then
        
        local FALLBACK_PALETTE = {
            "#FF0000", -- red
            "#FFA947", -- orange
            "#FFFF00", -- yellow
            "#00AA66", -- olive -> lime
            "#88FF77", -- green -> forest
            "#0bc4c2", -- cyan
            "#56A1FC", -- blue
            "#9500FF", -- purple
            "#FF00E6", -- pink
        }

        local function parse_hex(hex_str)
            if type(hex_str) == "string" then
                return tonumber(hex_str:gsub("#", "0x"))
            elseif type(hex_str) == "number" then
                return hex_str
            end
            return nil
        end

        local function get_dynamic_palette()
            local palette = {}
            local bb_ok, BlitBuffer = pcall(original_require, "ffi/blitbuffer")
            local color_keys = {"red", "orange", "yellow", "olive", "green", "cyan", "blue", "purple", "pink"}
            
            for i, key in ipairs(color_keys) do
                local color_val = nil
                
                -- Try to pull from the active UI memory first
                if bb_ok and BlitBuffer and type(BlitBuffer.HIGHLIGHT_COLORS) == "table" then
                    color_val = parse_hex(BlitBuffer.HIGHLIGHT_COLORS[key])
                end
                
                -- CRITICAL FIX: If a specific color (like Pink) isn't in memory yet,
                -- fallback for JUST that color, ensuring the palette is always 9 items.
                if not color_val then
                    color_val = parse_hex(FALLBACK_PALETTE[i])
                end
                
                if color_val then table.insert(palette, color_val) end
            end
            
            if #palette == 0 then palette = { 0x8AE234 } end
            return palette
        end

        local orig_buildBookDayWidget = loaded.buildBookDayWidget
        if type(orig_buildBookDayWidget) == "function" then
            loaded.buildBookDayWidget = function(self, book, ...)
                local palette = get_dynamic_palette()
                self._custom_color_palette = palette
                
                if book and book.id_book and #palette > 0 then
                    self.book_colors = self.book_colors or {}
                    local num = tonumber(book.id_book:match("%d+")) or 1
                    local color_index = (num % #palette) + 1
                    self.book_colors[book.id_book] = palette[color_index]
                end

                local widget = orig_buildBookDayWidget(self, book, ...)
                if widget and type(widget) == "table" then
                    widget._appearance_ignored = true 
                end
                return widget
            end
        end
        loaded._highlight_patched = true
    end

    return loaded
end

return {}